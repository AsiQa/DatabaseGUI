package utils;

public class Constants {

    public static final String MSSQL_IP = "147.91.175.155";
    public static final String MSSQL_DATABASE = "tim_44_bp2020";    //RAF_UI_2016_Full
    public static final String MSSQL_USERNAME = "tim_44_bp2020";    //-
    public static final String MSSQL_PASSWORD = "M66S4pRT";         //-

}
