package controller;

import gui.MainFrame;
import resource.implementation.Entity;

import javax.swing.*;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.TreePath;
import java.awt.*;

public class treeController implements TreeSelectionListener {


    @Override
    public void valueChanged(TreeSelectionEvent e) {

        TreePath path = e.getPath();
        boolean b = false;
        int i=0;

        if(path.getLastPathComponent() instanceof Entity){

            JTabbedPane tp = MainFrame.getInstance().getTp();


            JTable table = new JTable();

            table = new JTable();
            table.setPreferredScrollableViewportSize(new Dimension(500, 400));
            table.setFillsViewportHeight(true);



            for(i=0; i<tp.getTabCount(); i++){
                if(tp.getTitleAt(i).equals(path.getLastPathComponent().toString().toUpperCase())){
                    b = true;
                    break;
                };
            }

            if(b) {
                MainFrame.getInstance().getAppCore().readDataFromTable((path.getLastPathComponent().toString().toUpperCase()));
                tp.setSelectedIndex(i);
            }
            else {
                tp.addTab(path.getLastPathComponent().toString().toUpperCase(), table);
                tp.setPreferredSize(new Dimension(0,22));
                MainFrame.getInstance().getAppCore().readDataFromTable((path.getLastPathComponent().toString().toUpperCase()));
            }

        }
    }
}
