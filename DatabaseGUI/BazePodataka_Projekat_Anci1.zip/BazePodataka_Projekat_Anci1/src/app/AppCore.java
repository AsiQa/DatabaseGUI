package app;

import database.Database;
import database.DatabaseImplementation;
import database.MSSQLrepository;
import database.settings.Settings;
import database.settings.SettingsImplementation;
import gui.pretraga.PretragaGUI;
import gui.table.TableModel;

import observer.Notification;
import observer.Publisher;
import observer.Subscriber;
import observer.enums.NotificationCode;
import observer.implementation.PublisherImplementation;
import resource.DBNode;
import resource.implementation.InformationResource;
import utils.Constants;

import java.util.ArrayList;
import java.util.List;

public class AppCore extends PublisherImplementation {

    private Database database;
    private Settings settings;
    private TableModel tableModel;
    private PretragaGUI pretragaGUI;


    public AppCore() {
        this.settings = initSettings();
        this.database = new DatabaseImplementation(new MSSQLrepository(this.settings));
        tableModel = new TableModel();
    }

    public PretragaGUI getPretragaGUI() {
        return pretragaGUI;
    }

    private Settings initSettings() {
        Settings settingsImplementation = new SettingsImplementation();
        settingsImplementation.addParameter("147.91.175.155", Constants.MSSQL_IP);      //mssql_ip
        settingsImplementation.addParameter("tim_44_bp2020", Constants.MSSQL_DATABASE); //mssql_database
        settingsImplementation.addParameter("tim_44_bp2020", Constants.MSSQL_USERNAME); //mssql_username
        settingsImplementation.addParameter("M66S4pRT", Constants.MSSQL_PASSWORD);      //mssql_password
        return settingsImplementation;
    }


    public void loadResource(){
        InformationResource ir = (InformationResource) this.database.loadResource();
        this.notifySubscribers(new Notification(NotificationCode.RESOURCE_LOADED,ir));
    }
    public InformationResource loadResourceNODE(){
        InformationResource ir = (InformationResource) this.database.loadResource();
        return ir;
    }

    public void readDataFromTable(String fromTable){

        tableModel.setRows(this.database.readDataFromTable(fromTable));

        //Zasto ova linija moze da ostane zakomentarisana?
        //this.notifySubscribers(new Notification(NotificationCode.DATA_UPDATED, this.getTableModel()));
    }



    public TableModel getTableModel() {
        return tableModel;
    }

    public void setTableModel(TableModel tableModel) {
        this.tableModel = tableModel;
    }



}
