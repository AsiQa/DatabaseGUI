package actions;

import javax.swing.*;
import java.awt.event.ActionEvent;

public abstract class AbstractDBAction extends AbstractAction {
    // necemo ikonice
}
