package actions;

import gui.MainFrame;
import gui.pretraga.PretragaGUI;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

public class SearchAction extends AbstractDBAction {



    public SearchAction(){
        putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_O, ActionEvent.CTRL_MASK));
        putValue(NAME, "    Search    ");
        putValue(SHORT_DESCRIPTION, "Search FRAME");

    }



    @Override
    public void actionPerformed(ActionEvent actionEvent) {

        PretragaGUI pretragaGUI = PretragaGUI.getInstance();

    }

    public PretragaGUI getPretragaGui(){
        return PretragaGUI.getInstance();
    }

}