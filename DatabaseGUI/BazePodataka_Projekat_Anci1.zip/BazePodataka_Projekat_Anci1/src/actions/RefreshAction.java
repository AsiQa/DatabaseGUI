package actions;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

public class RefreshAction extends AbstractDBAction {

    public RefreshAction(){
        putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_O, ActionEvent.CTRL_MASK));
        putValue(NAME, "Refresh ");
        putValue(SHORT_DESCRIPTION, "Refresh database");
    }



    @Override
    public void actionPerformed(ActionEvent actionEvent) {
        //radi nesto

    }
}