package observer.enums;

public enum NotificationCode {
    DATA_UPDATED,
    RESOURCE_LOADED
}
