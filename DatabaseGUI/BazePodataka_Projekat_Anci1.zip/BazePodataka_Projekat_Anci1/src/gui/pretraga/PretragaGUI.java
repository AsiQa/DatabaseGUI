package gui.pretraga;

import actions.ActionManager;
import gui.MainFrame;
import resource.DBNode;
import resource.DBNodeComposite;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.List;

public class PretragaGUI extends JFrame implements ItemListener {

    private DBNodeComposite entity,node;
    private JComboBox tabele,kolone,operacijeBrojeva,operacijeString;
    private int brojac_poziva_statusChanged = 0;
    private Boolean selektovanaKolona, selektovanZnakOrString = false;
    private JFrame frame;
    private JPanel panelKolona;
    private ActionManager actionManager;
    private static PretragaGUI instance = null;

    public JFrame getFrame() {
        return frame;
    }

    public void setFrame(JFrame frame) {
        this.frame = frame;
    }

    public JPanel getPanelKolona() {
        return panelKolona;
    }

    public void setPanelKolona(JPanel panelKolona) {
        this.panelKolona = panelKolona;
    }

    private PretragaGUI(){
    }

    public static PretragaGUI getInstance(){
        if (instance==null){
            instance=new PretragaGUI();
            instance.initialise();
        }
        return instance;
    }
    public void initialise() {

        JFrame frame = new JFrame("GUI ZA PRETRAGU");
        frame.setLayout(new FlowLayout());


        entity = MainFrame.getInstance().getIr();
        //System.out.println(entity);
        List<DBNode> entityList = entity.getChildren();

        ArrayList<String> data = new ArrayList<>();
        for(Object o : entityList){
            data.add(o.toString());
        }

        String test[] = data.toArray(new String[0]);

        tabele = new JComboBox(test);
        tabele.addItemListener(getInstance());
        frame.add(new JLabel("SELECT * FROM "));
        frame.add(tabele);
        frame.add(new JLabel("WHERE"));
        frame.pack();
        frame.setVisible(true);

        this.panelKolona = new JPanel();


    }




    @Override
    public void itemStateChanged(ItemEvent e) {
        if(brojac_poziva_statusChanged % 2 == 0){
            if(e.getSource() == tabele){
                System.out.println(tabele.getSelectedItem());

                ArrayList<String> data = new ArrayList<>();
                node = (DBNodeComposite) entity.getChildByName(tabele.getSelectedItem().toString());
                List<DBNode> entityList = node.getChildren();
                for(Object o : entityList){
                    data.add(o.toString());
                }
                String test[] = data.toArray(new String[0]);
                System.out.println(test);
                new DodajKolonu(test,selektovanaKolona);
                selektovanaKolona = true;
            }
        }

    }
}
