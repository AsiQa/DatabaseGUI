package gui.pretraga;

import javax.swing.*;

public class DodajKolonu {

    PretragaGUI pretragaGUI = PretragaGUI.getInstance();
    JPanel panelKolona = pretragaGUI.getPanelKolona();
    JComboBox kolone;



    public DodajKolonu(String[] test,boolean selektovanaKolona){
        if(selektovanaKolona){
            pretragaGUI.getFrame().remove(panelKolona);
        }

        kolone = new JComboBox(test);
        kolone.addItemListener(PretragaGUI.getInstance());
        this.panelKolona.add(kolone);
        pretragaGUI.getFrame().add(panelKolona);
        pretragaGUI.getFrame().pack();
        pretragaGUI.getFrame().revalidate();
    }
}
