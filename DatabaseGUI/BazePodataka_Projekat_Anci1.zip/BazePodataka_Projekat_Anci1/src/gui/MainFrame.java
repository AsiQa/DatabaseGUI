package gui;

import actions.ActionManager;
import app.AppCore;
import app.Main;

import controller.treeController;
import observer.Notification;
import observer.Subscriber;
import observer.enums.NotificationCode;
import resource.DBNode;
import resource.implementation.InformationResource;


import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.plaf.SplitPaneUI;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreeNode;
import javax.tools.Tool;
import java.awt.Dimension;
import java.util.Spliterator;
import java.util.Vector;


public class MainFrame extends JFrame implements Subscriber {

    private static MainFrame instance = null;

    private AppCore appCore;
    private ActionManager actionManager;
    private Toolbar toolbar;

    private JTabbedPane tp;

    private JTable jTableA,jTableB;
    private JScrollPane jsp;
    private JPanel bottomStatus;
    private JTree tree;
    private DefaultTreeModel treeModel;
    private JButton pretragaButton;
    private InformationResource ir;
    //private InformationResource ir = MainFrame.getInstance().getAppCore().loadResourceNODE();

    private JSplitPane splitPaneV,splitPaneH;


    private MainFrame() {

    }

    public static MainFrame getInstance(){
        if (instance==null){
            instance=new MainFrame();
            instance.initialise();
        }
        return instance;
    }


    private void initialise() {
        this.setTitle("GUI INTERFEJS");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        actionManager = new ActionManager();
        toolbar = new Toolbar();
        tp = new JTabbedPane();

        tp.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent changeEvent) {

                JTabbedPane sourceTabbedPane = (JTabbedPane) changeEvent.getSource();
                int index = sourceTabbedPane.getSelectedIndex();
                System.out.println("Tab changed to: " + sourceTabbedPane.getTitleAt(index));
                getAppCore().readDataFromTable((sourceTabbedPane.getTitleAt(index)));
            }
        });

        JPanel panelA = new JPanel();
        JPanel panelB1 = new JPanel();
        JPanel panelB2 = new JPanel();
        JPanel panelC1 = new JPanel();
        JPanel panelC2 = new JPanel();





        splitPaneH = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,panelB1,panelB2);
        splitPaneH.setDividerLocation(140);
        panelA.add(splitPaneH);
        splitPaneV = new JSplitPane(JSplitPane.VERTICAL_SPLIT,panelC1,panelC2);

        tree = new JTree();

        panelB1.add(tree);
        panelB2.add(splitPaneV);

        tp.setPreferredSize(new Dimension(0,22));


        jTableA = new JTable();
        jTableA.setPreferredScrollableViewportSize(new Dimension(500, 400));
        jTableA.setFillsViewportHeight(true);

        jTableB = new JTable();
        jTableB.setPreferredScrollableViewportSize(new Dimension(500, 400));
        jTableB.setFillsViewportHeight(true);



        JScrollPane scroll1 = new JScrollPane(jTableA);
        JScrollPane scroll2 = new JScrollPane(jTableB);

        panelC1.setLayout(new BoxLayout(panelC1, BoxLayout.Y_AXIS));
        panelC1.add(tp);
        panelC1.add(scroll1);
        panelC1.add(toolbar);



        panelC2.add(scroll2);




        //this.getContentPane().add(panelA);
        this.getContentPane().add(splitPaneH);

       // this.add(new JScrollPane(jTableA));

        //velicina prozora je mala, mora da se poveca
        this.setSize(900,900);
        //this.pack();          //podesava velicinu frame-a onoliku kolike su njene komponente
        this.setLocationRelativeTo(null);
        this.setVisible(true);


    }

    public void setAppCore(AppCore appCore) {
        this.appCore = appCore;
        this.appCore.addSubscriber(this);
        this.jTableA.setModel(appCore.getTableModel());
        this.jTableB.setModel(appCore.getTableModel());
        DefaultTreeModel treeModel = new DefaultTreeModel(appCore.loadResourceNODE());
        this.tree.setModel(treeModel);
        this.tree.addTreeSelectionListener(new treeController());
        this.ir = appCore.loadResourceNODE();
    }

    public InformationResource getIr() {
        return ir;
    }

    @Override
    public void update(Notification notification) {

        if (notification.getCode() == NotificationCode.RESOURCE_LOADED){
            System.out.println((InformationResource)notification.getData());
        }

        else{
            jTableA.setModel((TableModel) notification.getData());
            jTableB.setModel((TableModel) notification.getData());
        }

    }

    public AppCore getAppCore() {
        return appCore;
    }

    public ActionManager getActionManager() {
        return actionManager;
    }

    public JTabbedPane getTp(){return tp;}
}
