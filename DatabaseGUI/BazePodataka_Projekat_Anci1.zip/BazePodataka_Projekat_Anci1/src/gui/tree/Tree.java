package gui.tree;

import javax.swing.*;

public class Tree extends JTree {


}
