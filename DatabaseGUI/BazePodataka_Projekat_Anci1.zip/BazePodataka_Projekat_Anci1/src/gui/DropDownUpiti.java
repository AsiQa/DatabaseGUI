package gui;

import app.AppCore;
import resource.DBNode;
import resource.DBNodeComposite;
import resource.enums.AttributeType;
import resource.implementation.Attribute;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.List;

public class DropDownUpiti extends JFrame implements ItemListener {


    static JPanel panel;
    static JFrame frame = new JFrame("gui");
    static JLabel label1, label2;
    static Boolean ispitano = false;
    static Boolean ispitanComboString = false;
    static Boolean ispitanComboNotString = false;
    static Boolean ispitanComboAndOr = false;
    static int brojac_poziva_statusChanged = 0;
    static int brojac = 2;

    static JComboBox tabele,kolone;
    static JComboBox comboBoxAndOr,comboBoxZnaci,comboBoxString;
    static JTextField textField;
    static DBNodeComposite entity,node;
    static Attribute kolona;

    

    public static JPanel getPanel() {
        return panel;
    }

    public static void main(String[] args){

        AppCore appCore = new AppCore();
        MainFrame mainFrame = MainFrame.getInstance();
        mainFrame.setAppCore(appCore);

        //frame = new JFrame("gui");
        frame.setLayout(new FlowLayout());
        DropDownUpiti object = new DropDownUpiti();


        entity =  MainFrame.getInstance().getAppCore().loadResourceNODE();
        List<DBNode> entityList = entity.getChildren();

        ArrayList<String> data = new ArrayList<>();
        for(Object o : entityList){
            data.add(o.toString());
        }

        String test[] = data.toArray(new String[0]);

        tabele = new JComboBox(test);
        tabele.addItemListener(object);


        label1 = new JLabel("SELECT * FROM ");
        label2 = new JLabel("where");
        label1.setForeground(Color.BLUE);
        label2.setForeground(Color.red);
        JButton searchButton = new JButton("SEARCH");


        frame.add(searchButton);
        frame.add(label1);  //0
        frame.add(tabele);  //1
        frame.add(label2);  //2

        frame.pack();
        frame.setVisible(true);




    }

    @Override
    public void itemStateChanged(ItemEvent e) {


        // dodati metodu koja uklanja panel iz dodajUpit u slucaju da se korisnik predomisli
        // npr. prvo selektujemo DEPARTMENTS -> pojavi nam se novi panel sa kolonama DEPARTMENTS tabele
        // drugo selektujemo JOB_HISTORY -> brise se panel za DEPARTMENTS kolone i dodaje se panel za JOB_HISTORY kolone


        brojac_poziva_statusChanged++;
        if(brojac_poziva_statusChanged % 2 == 1){


            if(e.getSource() == comboBoxAndOr){

                ispitano = false;
                ispitanComboAndOr = true;
                ArrayList<String> data = new ArrayList<>();
                node = (DBNodeComposite) entity.getChildByName(tabele.getSelectedItem().toString());
                List<DBNode> entityList = node.getChildren();
                for(Object o : entityList){
                    data.add(o.toString());
                    }
                String test[] = data.toArray(new String[0]);
                System.out.println(data);
               // frame.add(new JLabel("tako"));
                dodajKolonu(test);

                ispitano = true;
            }
            if(e.getSource() == comboBoxZnaci){
                System.out.println(comboBoxZnaci.getSelectedItem());
                ispitanComboNotString = true;
            }
            if(e.getSource() == comboBoxString){
                System.out.println(comboBoxString.getSelectedItem());
                ispitanComboString = true;
            }
            if(e.getSource() == tabele){
                System.out.println(tabele.getSelectedItem());
                // node = (DBNodeComposite) MainFrame.getInstance().getAppCore().loadResourceNODE().getChildByName(tabele.getSelectedItem().toString());
                ArrayList<String> data = new ArrayList<>();
                node = (DBNodeComposite) entity.getChildByName(tabele.getSelectedItem().toString());
                List<DBNode> entityList = node.getChildren();
                for(Object o : entityList){
                    data.add(o.toString());
                }
                String test[] = data.toArray(new String[0]);
                System.out.println(test);
                dodajKolonu(test);
                ispitano = true;
            }
            if(e.getSource() == kolone){
                ispitano = true;
                System.out.println(kolone.getSelectedItem());
                kolona = (Attribute) node.getChildByName(kolone.getSelectedItem().toString());
                AttributeType atribut = kolona.getAttributeType();
                if(atribut.toString().equalsIgnoreCase("DATE") || atribut.toString().equalsIgnoreCase("INT")
                        || atribut.toString().equalsIgnoreCase("SMALLINT") || atribut.toString().equalsIgnoreCase("FLOAT")
                        || atribut.toString().equalsIgnoreCase("TIME") || atribut.toString().equalsIgnoreCase("NUMERIC")
                        || atribut.toString().equalsIgnoreCase("DECIMAL") || atribut.toString().equalsIgnoreCase("REAL")
                        || atribut.toString().equalsIgnoreCase("DATETIME") || atribut.toString().equalsIgnoreCase("BIT")
                        || atribut.toString().equalsIgnoreCase("BIGINT") || atribut.toString().equalsIgnoreCase("SMALLINT")) {
                   dodajBoxZnaci();
                   dodajAndOr();
                   ispitanComboNotString = true;
                   System.out.println(atribut.toString());
                }
                if(atribut.toString().equalsIgnoreCase("CHAR") || atribut.toString().equalsIgnoreCase("VARCHAR")
                        || atribut.toString().equalsIgnoreCase("TEXT") || atribut.toString().equalsIgnoreCase("NVARCHAR")) {
                    dodajBoxString();
                    dodajAndOr();
                    ispitanComboString = true;
                    System.out.println(atribut.toString());
                }
            }
        }
    }

    static void dodajKolonu(String test[]){
        if(ispitanComboAndOr){
            ispitanComboNotString = true;
            ispitanComboString = true;
        }
        if(ispitano){
            int compCount = frame.getContentPane().getComponentCount();
            System.out.println(compCount);
            for(int i = 4; i < compCount ; i++){
                frame.getContentPane().remove(4);
            }

            ispitano = false;
        }
        DropDownUpiti object = new DropDownUpiti();
        kolone = new JComboBox(test);
        kolone.addItemListener(object);
        frame.add(kolone);  //3
        frame.pack();
        frame.revalidate();

    }
    static void dodajBoxZnaci(){

        if((ispitanComboString || ispitanComboNotString) && !ispitanComboAndOr){
            int compCount = frame.getContentPane().getComponentCount();
            System.out.println(compCount);
            for(int i = 5; i < compCount ; i++){
                frame.getContentPane().remove(5);
            }
            ispitanComboString = false;
            ispitanComboNotString = false;
        }
        String znaci[] = {"<" , ">" , "=" , "<=" , ">=" , "!="};
        comboBoxZnaci = new JComboBox(znaci);
        DropDownUpiti object = new DropDownUpiti();
        comboBoxZnaci.addItemListener(object);
        frame.add(comboBoxZnaci);
        JTextField textField = new JTextField("ovde stoji broj");
        textField.setEditable(true);
        frame.add(textField);
        frame.pack();
        frame.revalidate();
    }
    static void dodajBoxString(){
        if((ispitanComboString || ispitanComboNotString) && !ispitanComboAndOr){
            int compCount = frame.getContentPane().getComponentCount();
            System.out.println(compCount);
            for(int i = 5; i < compCount ; i++){
                frame.getContentPane().remove(5);
            }
            ispitanComboString = false;
            ispitanComboNotString =false;
        }
        String znaci[]= {"EQUALS" , "LIKE" , "CONTAINS"};
        comboBoxString = new JComboBox(znaci);
        DropDownUpiti object = new DropDownUpiti();
        frame.add(comboBoxString);
        JTextField textField = new JTextField("ovde stoji string");
        textField.setEditable(true);
        frame.add(textField);
        frame.pack();
        frame.revalidate();
    }
    static void dodajAndOr(){


        String andOr[] = {"-" , "AND" , "OR"};
        comboBoxAndOr = new JComboBox(andOr);
        DropDownUpiti object = new DropDownUpiti();
        comboBoxAndOr.addItemListener(object);
        frame.add(comboBoxAndOr);
        frame.pack();
        frame.revalidate();
    }
}
