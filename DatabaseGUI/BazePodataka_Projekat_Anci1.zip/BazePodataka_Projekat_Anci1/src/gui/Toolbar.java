package gui;

import app.AppCore;

import javax.swing.*;
import java.awt.*;

public class Toolbar extends JToolBar {

    public Toolbar(){
        super();
        addSeparator(new Dimension(300,50));
        add(MainFrame.getInstance().getActionManager().getDeleteAction());
        add(MainFrame.getInstance().getActionManager().getUpdateAction());
        add(MainFrame.getInstance().getActionManager().getAddAction());
        add(MainFrame.getInstance().getActionManager().getRefreshAction());
        add(MainFrame.getInstance().getActionManager().getSearchAction());


    }
}
