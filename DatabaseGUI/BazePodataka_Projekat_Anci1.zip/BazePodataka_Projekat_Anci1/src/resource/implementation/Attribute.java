package resource.implementation;


import resource.DBNode;
import resource.DBNodeComposite;
import resource.enums.AttributeType;
import resource.enums.ConstraintType;


public class Attribute extends DBNodeComposite {


    private AttributeType attributeType;
    private int length;
    private Attribute inRelationWith;

    public Attribute(String name, DBNode parent) {
        super(name, parent);
    }

    public Attribute(String name, DBNode parent, AttributeType attributeType, int length, String isNullable) {
        super(name, parent);
        this.attributeType = attributeType;
        this.length = length;
        if(isNullable.equalsIgnoreCase("no")){
            this.addChild(new AttributeConstraint("NOT_NULL",this, ConstraintType.NOT_NULL));
        }else{
            this.addChild(new AttributeConstraint("NULLABLE",this, ConstraintType.NULLABLE));
        }
    }

    @Override
    public void addChild(DBNode child) {
        if (child != null && child instanceof AttributeConstraint){
            AttributeConstraint attributeConstraint = (AttributeConstraint) child;
            this.getChildren().add(attributeConstraint);
        }
    }

    public AttributeType getAttributeType() {
        return attributeType;
    }

    public int getLength() {
        return length;
    }

    public void setInRelationWith(Attribute inRelationWith) {
        this.inRelationWith = inRelationWith;
    }

}
